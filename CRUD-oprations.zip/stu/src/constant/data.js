export const data = [
    {
        id: 1,
        name: "Umer",
        email: "umer@gmail.com",
        rollNo: "1234",
        class: "BSCS",
    },
    {
        id: 2,
        name: "Ali",
        email: "ali@gmail.com",
        rollNo: "1235",
        class: "BSCS",
    },
    {
        id: 3,
        name: "Ahmed",
        email: "ahmed@gmail.com",
        rollNo: "1236",
        class: "BSCS",
    },
]