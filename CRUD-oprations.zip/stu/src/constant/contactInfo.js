export const contacts = [
    {
        name: "Naveed",
        email: "naveed@gmail.com",
        message: " lorem ipsum dolor sit amet"
    },
    {
        name: "Ali",
        email: "ali@gmail.com",
        message: " lorem ipsum dolor sit amet"
    }
]