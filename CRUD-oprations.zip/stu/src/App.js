import Navigation from "./navigation/Navigation"
import "./style.css"
export default function App() {

  
  return (
    <div >
    <Navigation/>
    </div>
  )
}
